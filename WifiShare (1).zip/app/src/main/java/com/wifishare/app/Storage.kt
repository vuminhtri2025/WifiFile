package com.wifishare.app

import android.content.Context
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

object Storage {
    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "shared").also { it.mkdirs() }
    }

    fun list(ctx: Context): List<File> =
        (dir(ctx).listFiles { f -> f.isFile && !f.name.startsWith(".") } ?: emptyArray())
            .sortedByDescending { it.lastModified() }

    fun safeName(raw: String): String {
        var n = File(raw).name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim()
        if (n.startsWith(".")) n = "_$n"
        if (n.isEmpty()) n = "file"
        return if (n.length > 200) n.takeLast(200) else n
    }

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base ($i)$ext")
            i++
        }
        return f
    }

    fun fmtSize(n: Long): String {
        if (n < 1024) return "$n B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = n.toDouble()
        var i = -1
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }

    /** IPv4 của WiFi hoặc hotspot (wlan*, ap*, swlan*, eth*, p2p*). */
    fun localIp(): String? {
        return try {
            val re = Regex("^(wlan|swlan|ap|eth|p2p).*")
            val found = mutableListOf<Pair<String, String>>()
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in ifs) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        a.hostAddress?.let { found += ni.name to it }
                    }
                }
            }
            found.firstOrNull { re.matches(it.first) }?.second
        } catch (e: Exception) {
            null
        }
    }
}
