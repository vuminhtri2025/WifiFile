package com.wifishare.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var dot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvHint: TextView
    private lateinit var btnToggle: MaterialButton
    private lateinit var listBox: android.widget.LinearLayout
    private lateinit var tvEmpty: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importFiles(uris)
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dot = findViewById(R.id.dot)
        tvStatus = findViewById(R.id.tv_status)
        tvUrl = findViewById(R.id.tv_url)
        tvHint = findViewById(R.id.tv_hint)
        btnToggle = findViewById(R.id.btn_toggle)
        listBox = findViewById(R.id.list_box)
        tvEmpty = findViewById(R.id.tv_empty)

        btnToggle.setOnClickListener {
            if (FileServerService.running) {
                startService(Intent(this, FileServerService::class.java).setAction(FileServerService.ACTION_STOP))
            } else {
                ContextCompat.startForegroundService(
                    this, Intent(this, FileServerService::class.java).setAction(FileServerService.ACTION_START)
                )
            }
        }
        findViewById<View>(R.id.btn_add).setOnClickListener { pick.launch(arrayOf("*/*")) }
        tvUrl.setOnClickListener {
            if (FileServerService.url.isNotEmpty()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("url", FileServerService.url))
                Toast.makeText(this, "Đã sao chép địa chỉ", Toast.LENGTH_SHORT).show()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onStart() {
        super.onStart()
        FileServerService.listener = { refresh() }
        refresh()
    }

    override fun onStop() {
        FileServerService.listener = null
        super.onStop()
    }

    private fun refresh() {
        val running = FileServerService.running
        val url = FileServerService.url
        tvStatus.text = if (running) "Đang chạy" else "Đã tắt"
        dot.backgroundTintList = ColorStateList.valueOf(if (running) 0xFF7EE2A8.toInt() else 0xFF8A919C.toInt())
        tvUrl.text = when {
            !running -> "Bật chia sẻ để lấy địa chỉ"
            url.isEmpty() -> "Chưa kết nối WiFi/hotspot"
            else -> url
        }
        tvHint.text = if (running && url.isNotEmpty())
            "Nhập địa chỉ trên vào trình duyệt của thiết bị khác (cùng WiFi). Chạm để sao chép."
        else "Hai thiết bị phải dùng chung WiFi, hoặc kết nối vào hotspot của máy này."
        btnToggle.text = if (running) "Dừng chia sẻ" else "Bắt đầu chia sẻ"
        btnToggle.backgroundTintList = ColorStateList.valueOf(if (running) 0xFFF4A3A3.toInt() else 0xFFE6E8EC.toInt())

        val files = Storage.list(this)
        listBox.removeAllViews()
        tvEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        val df = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        for (f in files) {
            val row = layoutInflater.inflate(R.layout.item_file, listBox, false)
            row.findViewById<TextView>(R.id.f_name).text = f.name
            row.findViewById<TextView>(R.id.f_meta).text =
                Storage.fmtSize(f.length()) + "  •  " + df.format(Date(f.lastModified()))
            row.findViewById<View>(R.id.f_send).setOnClickListener {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val i = Intent(Intent.ACTION_SEND).setType("*/*")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "Gửi / lưu file"))
            }
            row.findViewById<View>(R.id.f_del).setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("Xóa \"" + f.name + "\"?")
                    .setPositiveButton("Xóa") { _, _ -> f.delete(); refresh(); FileWidgetProvider.updateAll(this) }
                    .setNegativeButton("Hủy", null)
                    .show()
            }
            listBox.addView(row)
        }
    }

    private fun importFiles(uris: List<Uri>) {
        Thread {
            val dir = Storage.dir(this)
            for (u in uris) {
                try {
                    var name = "file"
                    contentResolver.query(u, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (i >= 0) c.getString(i)?.let { name = it }
                        }
                    }
                    val target = Storage.unique(dir, Storage.safeName(name))
                    contentResolver.openInputStream(u)?.use { ins ->
                        target.outputStream().use { out -> ins.copyTo(out) }
                    }
                } catch (_: Exception) {
                }
            }
            runOnUiThread {
                refresh()
                FileWidgetProvider.updateAll(this)
            }
        }.start()
    }
}
