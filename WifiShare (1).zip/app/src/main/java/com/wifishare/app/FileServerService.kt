package com.wifishare.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class FileServerService : Service() {

    companion object {
        const val ACTION_START = "com.wifishare.app.START"
        const val ACTION_STOP = "com.wifishare.app.STOP"
        const val ACTION_TOGGLE = "com.wifishare.app.TOGGLE"
        const val PORT = 8080
        private const val CHANNEL = "wifishare"
        private const val NOTIF_ID = 1

        @Volatile var running = false
        @Volatile var url = ""
        @Volatile var listener: (() -> Unit)? = null
        private val main = Handler(Looper.getMainLooper())

        fun notifyChanged(ctx: Context) {
            val app = ctx.applicationContext
            main.post {
                listener?.invoke()
                FileWidgetProvider.updateAll(app)
            }
        }
    }

    private var server: FileServer? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "WiFi Share", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        val stop = action == ACTION_STOP || (action == ACTION_TOGGLE && running)
        // Luôn gọi startForeground trước (bắt buộc khi được start bằng startForegroundService)
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (stop) {
            shutdown()
        } else {
            startServer()
        }
        return START_NOT_STICKY
    }

    private fun startServer() {
        if (server != null) return
        try {
            val s = FileServer(PORT, Storage.dir(this), assets) { notifyChanged(this) }
            s.start(60_000, false)
            server = s
            running = true
            val ip = Storage.localIp()
            url = if (ip != null) "http://$ip:$PORT" else ""
            acquireWifiLock()
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
            notifyChanged(this)
        } catch (e: Exception) {
            Toast.makeText(this, "Không thể mở server: " + e.message, Toast.LENGTH_LONG).show()
            shutdown()
        }
    }

    private fun shutdown() {
        stopServer()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        notifyChanged(this)
    }

    private fun stopServer() {
        try { server?.stop() } catch (_: Exception) {}
        server = null
        running = false
        url = ""
        try { wifiLock?.release() } catch (_: Exception) {}
        wifiLock = null
    }

    @Suppress("DEPRECATION")
    private fun acquireWifiLock() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "wifishare").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, FileServerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = when {
            !running -> "Đang khởi động…"
            url.isEmpty() -> "Chưa kết nối WiFi/hotspot"
            else -> url
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_wifi)
            .setContentTitle("WiFi Share đang chia sẻ")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Dừng", stopI)
            .build()
    }

    override fun onDestroy() {
        stopServer()
        notifyChanged(this)
        super.onDestroy()
    }
}
