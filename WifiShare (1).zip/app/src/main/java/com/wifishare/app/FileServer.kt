package com.wifishare.app

import android.content.res.AssetManager
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.URLEncoder

class FileServer(
    port: Int,
    private val dir: File,
    private val assets: AssetManager,
    private val onChange: () -> Unit
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        return try {
            when {
                session.method == Method.GET && (uri == "/" || uri == "/index.html") -> page()
                session.method == Method.GET && uri == "/api/list" -> list()
                session.method == Method.GET && uri.startsWith("/files/") -> download(uri.removePrefix("/files/"))
                session.method == Method.POST && uri == "/api/upload" -> upload(session)
                else -> text(Status.NOT_FOUND, "Not found")
            }
        } catch (e: Exception) {
            text(Status.INTERNAL_ERROR, "Error: " + (e.message ?: "unknown"))
        }
    }

    private fun text(status: Status, msg: String): Response =
        NanoHTTPD.newFixedLengthResponse(status, "text/plain; charset=utf-8", msg)

    private fun page(): Response {
        val html = assets.open("index.html").use { String(it.readBytes(), Charsets.UTF_8) }
        val r = NanoHTTPD.newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html)
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun list(): Response {
        val arr = JSONArray()
        for (f in files()) {
            arr.put(JSONObject().put("name", f.name).put("size", f.length()).put("time", f.lastModified()))
        }
        val r = NanoHTTPD.newFixedLengthResponse(Status.OK, "application/json; charset=utf-8", arr.toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun files(): List<File> =
        (dir.listFiles { f -> f.isFile && !f.name.startsWith(".") } ?: emptyArray())
            .sortedByDescending { it.lastModified() }

    private fun download(rawName: String): Response {
        val f = File(dir, File(rawName).name)
        if (!f.isFile || f.name.startsWith(".")) return text(Status.NOT_FOUND, "Not found")
        val r = NanoHTTPD.newFixedLengthResponse(
            Status.OK, "application/octet-stream", FileInputStream(f), f.length()
        )
        val enc = URLEncoder.encode(f.name, "UTF-8").replace("+", "%20")
        val ascii = f.name.replace(Regex("[^\\x20-\\x7E]"), "_").replace("\"", "_")
        r.addHeader("Content-Disposition", "attachment; filename=\"$ascii\"; filename*=UTF-8''$enc")
        return r
    }

    /** Nhận file thô (raw body), tên file nằm ở query ?name=... */
    private fun upload(session: IHTTPSession): Response {
        val len = session.headers["content-length"]?.toLongOrNull()
            ?: return text(Status.BAD_REQUEST, "Missing Content-Length")
        val name = Storage.safeName(session.parameters["name"]?.firstOrNull() ?: "file")
        val tmp = File(dir, ".upload_" + System.nanoTime())
        var ok = false
        try {
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                val ins = session.inputStream
                var rem = len
                while (rem > 0) {
                    val n = ins.read(buf, 0, minOf(buf.size.toLong(), rem).toInt())
                    if (n < 0) throw IOException("Connection closed")
                    out.write(buf, 0, n)
                    rem -= n
                }
            }
            val target = Storage.unique(dir, name)
            ok = tmp.renameTo(target)
            if (!ok) throw IOException("Cannot save file")
            onChange()
            return NanoHTTPD.newFixedLengthResponse(
                Status.OK, "application/json; charset=utf-8",
                JSONObject().put("ok", true).put("name", target.name).toString()
            )
        } finally {
            if (!ok) tmp.delete()
        }
    }
}
