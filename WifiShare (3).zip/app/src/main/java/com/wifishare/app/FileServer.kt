package com.wifishare.app

import android.content.res.AssetManager
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.URLEncoder
import java.nio.file.Files
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.PriorityQueue
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Server duyệt toàn bộ bộ nhớ (từ [root]). Mọi API đều yêu cầu đăng nhập bằng PIN.
 * [statsFile] lưu số lần dùng mỗi thư mục để tự đẩy thư mục hay dùng lên đầu.
 */
class FileServer(
    port: Int,
    private val root: File,
    private val assets: AssetManager,
    private val pin: String,
    private val statsFile: File,
    private val onChange: () -> Unit
) : NanoHTTPD(port) {

    companion object {
        private val DOC = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "ods", "odp", "md", "html", "htm", "epub")
        private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
        private val VID = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v")
        private val AUD = setOf("mp3", "m4a", "wav", "flac", "aac", "ogg", "opus", "amr", "wma")
    }

    private val rootC: File = root.canonicalFile
    private val token: String = ByteArray(24).also { SecureRandom().nextBytes(it) }
        .joinToString("") { "%02x".format(it) }

    @Volatile private var fails = 0
    @Volatile private var lockUntil = 0L

    private val usage = HashMap<String, Int>()

    init {
        try {
            if (statsFile.exists()) {
                val o = JSONObject(statsFile.readText())
                for (k in o.keys()) usage[k] = o.optInt(k)
            }
        } catch (_: Exception) {
        }
    }

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        return try {
            if (session.method == Method.GET && (uri == "/" || uri == "/index.html")) return page()
            if (session.method == Method.POST && uri == "/api/login") return login(session)
            if (!authed(session)) return json(Status.UNAUTHORIZED, JSONObject().put("error", "auth"))

            when {
                session.method == Method.GET && uri == "/api/ls" -> ls(param(session, "path"))
                session.method == Method.GET && uri == "/api/find" -> find(session)
                session.method == Method.GET && uri == "/api/frequent" -> frequent()
                session.method == Method.GET && uri == "/dl" -> download(param(session, "path"))
                session.method == Method.GET && uri == "/zip" -> zip(param(session, "path"))
                session.method == Method.POST && uri == "/zipsel" -> zipSel(session)
                session.method == Method.POST && uri == "/api/upload" -> upload(session)
                else -> json(Status.NOT_FOUND, JSONObject().put("error", "Not found"))
            }
        } catch (e: Exception) {
            json(Status.INTERNAL_ERROR, JSONObject().put("error", e.message ?: "unknown"))
        }
    }

    // ---------- tiện ích ----------
    private fun param(s: IHTTPSession, k: String): String = s.parameters[k]?.firstOrNull() ?: ""

    private fun json(status: Status, o: JSONObject): Response {
        val r = NanoHTTPD.newFixedLengthResponse(status, "application/json; charset=utf-8", o.toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun authed(s: IHTTPSession): Boolean {
        val c = s.headers["cookie"] ?: return false
        return c.split(";").any { it.trim() == "tok=$token" }
    }

    private fun resolve(rel: String): File? {
        val f = File(root, rel).canonicalFile
        val ok = f.path == rootC.path || f.path.startsWith(rootC.path + File.separator)
        return if (ok) f else null
    }

    private fun relOf(f: File): String =
        if (f.path == rootC.path) "" else f.path.removePrefix(rootC.path + File.separator)

    private fun disposition(name: String): String {
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        val ascii = name.replace(Regex("[^\\x20-\\x7E]"), "_").replace("\"", "_")
        return "attachment; filename=\"$ascii\"; filename*=UTF-8''$enc"
    }

    private fun usageOf(rel: String): Int = synchronized(usage) { usage[rel] ?: 0 }

    private fun bump(rel: String) {
        if (rel.isEmpty()) return
        synchronized(usage) {
            usage[rel] = (usage[rel] ?: 0) + 1
            try {
                statsFile.writeText(JSONObject(usage as Map<*, *>).toString())
            } catch (_: Exception) {
            }
        }
    }

    private fun entry(f: File): JSONObject {
        val o = JSONObject().put("name", f.name).put("dir", f.isDirectory)
            .put("size", if (f.isDirectory) 0L else f.length()).put("time", f.lastModified())
            .put("path", relOf(f)).put("parent", relOf(f.parentFile ?: rootC))
        if (f.isDirectory) o.put("hot", usageOf(relOf(f)) >= 2)
        return o
    }

    // ---------- endpoints ----------
    private fun page(): Response {
        val html = assets.open("index.html").use { String(it.readBytes(), Charsets.UTF_8) }
        val r = NanoHTTPD.newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html)
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun login(s: IHTTPSession): Response {
        val now = System.currentTimeMillis()
        if (now < lockUntil) {
            return json(Status.FORBIDDEN, JSONObject().put("error", "Nhập sai nhiều lần, thử lại sau ít giây"))
        }
        val given = param(s, "pin")
        if (MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
            fails = 0
            val r = json(Status.OK, JSONObject().put("ok", true))
            r.addHeader("Set-Cookie", "tok=$token; Path=/; HttpOnly; SameSite=Lax")
            return r
        }
        fails++
        if (fails >= 5) {
            fails = 0
            lockUntil = now + 30_000
        }
        return json(Status.UNAUTHORIZED, JSONObject().put("error", "Sai mã PIN"))
    }

    private fun ls(rel: String): Response {
        val d = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!d.isDirectory) return json(Status.NOT_FOUND, JSONObject().put("error", "Không phải thư mục"))
        bump(relOf(d))
        val list = d.listFiles()
        // thư mục hay dùng lên đầu, sau đó theo tên
        val items = (list ?: emptyArray()).sortedWith(
            compareBy<File>({ !it.isDirectory }, { if (it.isDirectory) -usageOf(relOf(it)) else 0 }, { it.name.lowercase() })
        )
        val arr = JSONArray()
        for (f in items) arr.put(entry(f))
        return json(Status.OK, JSONObject().put("path", relOf(d)).put("entries", arr).put("denied", list == null))
    }

    private fun frequent(): Response {
        val snap = synchronized(usage) { usage.entries.map { it.key to it.value } }
        val arr = JSONArray()
        snap.filter { it.second >= 2 }
            .sortedByDescending { it.second }
            .mapNotNull { (rel, c) ->
                val f = resolve(rel)
                if (f != null && f.isDirectory) Triple(rel, f.name, c) else null
            }
            .take(8)
            .forEach { arr.put(JSONObject().put("path", it.first).put("name", it.second).put("count", it.third)) }
        return json(Status.OK, JSONObject().put("items", arr))
    }

    /** kind = recent | doc | image | video | audio | search (kèm q). */
    private fun find(s: IHTTPSession): Response {
        val kind = param(s, "kind").ifEmpty { "search" }
        val q = param(s, "q").trim().lowercase()
        if (kind == "search" && q.isEmpty()) {
            return json(Status.OK, JSONObject().put("entries", JSONArray()).put("truncated", false))
        }
        val exts: Set<String>? = when (kind) {
            "doc" -> DOC
            "image" -> IMG
            "video" -> VID
            "audio" -> AUD
            else -> null
        }
        val limit = if (kind == "recent") 100 else 300
        val heap = PriorityQueue<File>(11, compareBy<File> { it.lastModified() })
        val deadline = System.currentTimeMillis() + 7000
        var visited = 0
        var truncated = false

        fun walk(d: File) {
            if (truncated) return
            val list = d.listFiles() ?: return
            for (f in list) {
                if (System.currentTimeMillis() > deadline || visited > 300000) {
                    truncated = true
                    return
                }
                if (f.name.startsWith(".")) continue
                if (Files.isSymbolicLink(f.toPath())) continue
                if (f.isDirectory) {
                    if (d.path == rootC.path && f.name == "Android") continue
                    if (kind == "search" && f.name.lowercase().contains(q)) {
                        heap.add(f)
                        if (heap.size > limit) heap.poll()
                    }
                    walk(f)
                } else {
                    visited++
                    val n = f.name.lowercase()
                    if (exts != null && n.substringAfterLast('.', "") !in exts) continue
                    if (kind == "search" && !n.contains(q)) continue
                    heap.add(f)
                    if (heap.size > limit) heap.poll()
                }
            }
        }
        walk(rootC)

        val arr = JSONArray()
        for (f in heap.sortedByDescending { it.lastModified() }) arr.put(entry(f))
        return json(Status.OK, JSONObject().put("entries", arr).put("truncated", truncated))
    }

    private fun download(rel: String): Response {
        val f = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!f.isFile || !f.canRead()) return json(Status.NOT_FOUND, JSONObject().put("error", "Không đọc được file"))
        bump(relOf(f.parentFile ?: rootC))
        val r = NanoHTTPD.newFixedLengthResponse(
            Status.OK, "application/octet-stream", FileInputStream(f), f.length()
        )
        r.addHeader("Content-Disposition", disposition(f.name))
        return r
    }

    private fun zip(rel: String): Response {
        val d = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!d.isDirectory) return json(Status.NOT_FOUND, JSONObject().put("error", "Không phải thư mục"))
        bump(relOf(d))
        val name = if (d.path == rootC.path) "Bo-nho-trong" else d.name
        return streamZip("$name.zip") { z -> addDir(z, d, "") }
    }

    /** Tải nhiều mục đã chọn: form POST, trường "paths" là danh sách đường dẫn cách nhau bằng xuống dòng. */
    private fun zipSel(s: IHTTPSession): Response {
        s.parseBody(HashMap<String, String>())
        val items = param(s, "paths").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            .mapNotNull { resolve(it) }.filter { it.exists() && it.path != rootC.path }
        if (items.isEmpty()) return json(Status.BAD_REQUEST, JSONObject().put("error", "Chưa chọn mục nào"))
        items.firstOrNull()?.let { bump(relOf(it.parentFile ?: rootC)) }
        return streamZip("WiFiShare-${items.size}-muc.zip") { z ->
            val used = HashSet<String>()
            for (f in items) {
                val nm = uniqName(used, f.name)
                if (f.isDirectory) addDir(z, f, "$nm/") else addFile(z, f, nm)
            }
        }
    }

    private fun streamZip(fileName: String, fill: (ZipOutputStream) -> Unit): Response {
        val pipeIn = PipedInputStream(1 shl 16)
        val pipeOut = PipedOutputStream(pipeIn)
        Thread {
            try {
                ZipOutputStream(BufferedOutputStream(pipeOut)).use { z ->
                    z.setLevel(1)
                    fill(z)
                }
            } catch (e: Exception) {
                try { pipeOut.close() } catch (_: Exception) {}
            }
        }.start()
        val r = NanoHTTPD.newChunkedResponse(Status.OK, "application/zip", pipeIn)
        r.addHeader("Content-Disposition", disposition(fileName))
        return r
    }

    private fun uniqName(used: MutableSet<String>, name: String): String {
        if (used.add(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            val n = "$base ($i)$ext"
            if (used.add(n)) return n
            i++
        }
    }

    private fun addFile(z: ZipOutputStream, f: File, entryName: String) {
        val ins = try { FileInputStream(f) } catch (e: Exception) { return }
        ins.use {
            z.putNextEntry(ZipEntry(entryName))
            it.copyTo(z)
            z.closeEntry()
        }
    }

    private fun addDir(z: ZipOutputStream, dir: File, prefix: String) {
        val list = dir.listFiles() ?: return
        for (f in list) {
            if (Files.isSymbolicLink(f.toPath())) continue
            if (f.isDirectory) addDir(z, f, prefix + f.name + "/")
            else if (f.isFile) addFile(z, f, prefix + f.name)
        }
    }

    /** Nhận file thô vào thư mục ?path=..., tên file ở ?name=... */
    private fun upload(s: IHTTPSession): Response {
        val len = s.headers["content-length"]?.toLongOrNull()
            ?: return json(Status.BAD_REQUEST, JSONObject().put("error", "Missing Content-Length"))
        val dir = resolve(param(s, "path")) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!dir.isDirectory || !dir.canWrite()) {
            return json(Status.FORBIDDEN, JSONObject().put("error", "Không có quyền ghi vào thư mục này"))
        }
        val name = Storage.safeName(param(s, "name").ifEmpty { "file" })
        val tmp = File(dir, ".upload_" + System.nanoTime())
        var ok = false
        try {
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                val ins = s.inputStream
                var rem = len
                while (rem > 0) {
                    val n = ins.read(buf, 0, minOf(buf.size.toLong(), rem).toInt())
                    if (n < 0) throw IOException("Connection closed")
                    out.write(buf, 0, n)
                    rem -= n
                }
            }
            val target = Storage.unique(dir, name)
            ok = tmp.renameTo(target)
            if (!ok) throw IOException("Cannot save file")
            bump(relOf(dir))
            onChange()
            return json(Status.OK, JSONObject().put("ok", true).put("name", target.name))
        } finally {
            if (!ok) tmp.delete()
        }
    }
}
