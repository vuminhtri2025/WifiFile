package com.wifishare.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class FileWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, FileWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(ctx))
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            val running = FileServerService.running
            v.setTextViewText(R.id.w_status, if (running) "● Đang chạy" else "○ Đã tắt")
            v.setTextViewText(
                R.id.w_url,
                when {
                    !running -> "Nhấn Bật để chia sẻ file"
                    FileServerService.url.isEmpty() -> "Chưa kết nối WiFi/hotspot"
                    else -> FileServerService.url
                }
            )
            v.setTextViewText(R.id.w_count, if (running) "PIN: " + FileServerService.pin else "Chia sẻ toàn bộ bộ nhớ")
            v.setTextViewText(R.id.w_btn, if (running) "Tắt" else "Bật")
            v.setInt(
                R.id.w_btn, "setBackgroundResource",
                if (running) R.drawable.bg_widget_btn_stop else R.drawable.bg_widget_btn_start
            )

            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val toggle = PendingIntent.getForegroundService(
                ctx, 10,
                Intent(ctx, FileServerService::class.java).setAction(FileServerService.ACTION_TOGGLE),
                flags
            )
            v.setOnClickPendingIntent(R.id.w_btn, toggle)
            val open = PendingIntent.getActivity(ctx, 11, Intent(ctx, MainActivity::class.java), flags)
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }
    }
}
