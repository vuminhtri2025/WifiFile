package com.wifishare.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var dot: View
    private lateinit var tvStatus: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvPin: TextView
    private lateinit var btnToggle: MaterialButton
    private lateinit var permBox: LinearLayout

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        dot = findViewById(R.id.dot)
        tvStatus = findViewById(R.id.tv_status)
        tvUrl = findViewById(R.id.tv_url)
        tvHint = findViewById(R.id.tv_hint)
        tvPin = findViewById(R.id.tv_pin)
        btnToggle = findViewById(R.id.btn_toggle)
        permBox = findViewById(R.id.perm_box)

        findViewById<View>(R.id.btn_perm).setOnClickListener { requestStorage() }

        btnToggle.setOnClickListener {
            if (FileServerService.running) {
                startService(Intent(this, FileServerService::class.java).setAction(FileServerService.ACTION_STOP))
            } else if (!Storage.hasAccess(this)) {
                Toast.makeText(this, "Hãy cấp quyền truy cập file trước", Toast.LENGTH_SHORT).show()
                requestStorage()
            } else {
                ContextCompat.startForegroundService(
                    this, Intent(this, FileServerService::class.java).setAction(FileServerService.ACTION_START)
                )
            }
        }
        tvUrl.setOnClickListener {
            if (FileServerService.url.isNotEmpty()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("url", FileServerService.url))
                Toast.makeText(this, "Đã sao chép địa chỉ", Toast.LENGTH_SHORT).show()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            storagePerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    override fun onStart() {
        super.onStart()
        FileServerService.listener = { refresh() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        FileServerService.listener = null
        super.onStop()
    }

    private fun refresh() {
        val running = FileServerService.running
        val url = FileServerService.url
        tvStatus.text = if (running) "Đang chạy" else "Đã tắt"
        dot.backgroundTintList = ColorStateList.valueOf(if (running) 0xFF7EE2A8.toInt() else 0xFF8A919C.toInt())
        tvUrl.text = when {
            !running -> "Bật chia sẻ để lấy địa chỉ"
            url.isEmpty() -> "Chưa kết nối WiFi/hotspot"
            else -> url
        }
        tvHint.text = if (running && url.isNotEmpty())
            "Nhập địa chỉ trên vào trình duyệt của thiết bị khác (cùng WiFi), sau đó nhập PIN. Chạm địa chỉ để sao chép."
        else "Hai thiết bị phải dùng chung WiFi, hoặc kết nối vào hotspot của máy này."
        tvPin.text = if (running) FileServerService.pin else "------"
        btnToggle.text = if (running) "Dừng chia sẻ" else "Bắt đầu chia sẻ"
        btnToggle.backgroundTintList = ColorStateList.valueOf(if (running) 0xFFF4A3A3.toInt() else 0xFFE6E8EC.toInt())
        permBox.visibility = if (Storage.hasAccess(this)) View.GONE else View.VISIBLE
    }
}
