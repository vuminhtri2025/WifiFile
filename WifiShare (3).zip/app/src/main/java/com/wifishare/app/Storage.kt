package com.wifishare.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

object Storage {
    /** Gốc bộ nhớ trong (thường là /storage/emulated/0). */
    fun root(): File = Environment.getExternalStorageDirectory()

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun safeName(raw: String): String {
        var n = File(raw).name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim()
        if (n.startsWith(".")) n = "_$n"
        if (n.isEmpty()) n = "file"
        return if (n.length > 200) n.takeLast(200) else n
    }

    fun unique(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(dir, "$base ($i)$ext")
            i++
        }
        return f
    }

    /** IPv4 của WiFi hoặc hotspot (wlan*, ap*, swlan*, eth*, p2p*). */
    fun localIp(): String? {
        return try {
            val re = Regex("^(wlan|swlan|ap|eth|p2p).*")
            val found = mutableListOf<Pair<String, String>>()
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in ifs) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        a.hostAddress?.let { found += ni.name to it }
                    }
                }
            }
            found.firstOrNull { re.matches(it.first) }?.second
        } catch (e: Exception) {
            null
        }
    }
}
