plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wifishare.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.wifishare.app"
        minSdk = 26
        targetSdk = 34
        // Tăng tự động theo số lần build trên GitHub để cập nhật app đè lên bản cũ
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Keystore cố định -> mọi bản build đều cùng chữ ký -> cài đè/cập nhật được
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storeType = "jks"
            storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "wifishare123"
            keyAlias = System.getenv("KEY_ALIAS") ?: "wifishare"
            keyPassword = System.getenv("KEY_PASSWORD") ?: "wifishare123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/LICENSE*")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
}
