package com.wifishare.app

import android.content.res.AssetManager
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.URLEncoder
import java.nio.file.Files
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Server duyệt toàn bộ bộ nhớ (từ [root]). Mọi API đều yêu cầu đăng nhập bằng PIN.
 */
class FileServer(
    port: Int,
    private val root: File,
    private val assets: AssetManager,
    private val pin: String,
    private val onChange: () -> Unit
) : NanoHTTPD(port) {

    private val rootC: File = root.canonicalFile
    private val token: String = ByteArray(24).also { SecureRandom().nextBytes(it) }
        .joinToString("") { "%02x".format(it) }

    @Volatile private var fails = 0
    @Volatile private var lockUntil = 0L

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        return try {
            if (session.method == Method.GET && (uri == "/" || uri == "/index.html")) return page()
            if (session.method == Method.POST && uri == "/api/login") return login(session)
            if (!authed(session)) return json(Status.UNAUTHORIZED, JSONObject().put("error", "auth"))

            when {
                session.method == Method.GET && uri == "/api/ls" -> ls(param(session, "path"))
                session.method == Method.GET && uri == "/dl" -> download(param(session, "path"))
                session.method == Method.GET && uri == "/zip" -> zip(param(session, "path"))
                session.method == Method.POST && uri == "/api/upload" -> upload(session)
                else -> json(Status.NOT_FOUND, JSONObject().put("error", "Not found"))
            }
        } catch (e: Exception) {
            json(Status.INTERNAL_ERROR, JSONObject().put("error", e.message ?: "unknown"))
        }
    }

    // ---------- tiện ích ----------
    private fun param(s: IHTTPSession, k: String): String = s.parameters[k]?.firstOrNull() ?: ""

    private fun json(status: Status, o: JSONObject): Response {
        val r = NanoHTTPD.newFixedLengthResponse(status, "application/json; charset=utf-8", o.toString())
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun authed(s: IHTTPSession): Boolean {
        val c = s.headers["cookie"] ?: return false
        return c.split(";").any { it.trim() == "tok=$token" }
    }

    private fun resolve(rel: String): File? {
        val f = File(root, rel).canonicalFile
        val ok = f.path == rootC.path || f.path.startsWith(rootC.path + File.separator)
        return if (ok) f else null
    }

    private fun relOf(f: File): String =
        if (f.path == rootC.path) "" else f.path.removePrefix(rootC.path + File.separator)

    private fun disposition(name: String): String {
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        val ascii = name.replace(Regex("[^\\x20-\\x7E]"), "_").replace("\"", "_")
        return "attachment; filename=\"$ascii\"; filename*=UTF-8''$enc"
    }

    // ---------- endpoints ----------
    private fun page(): Response {
        val html = assets.open("index.html").use { String(it.readBytes(), Charsets.UTF_8) }
        val r = NanoHTTPD.newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html)
        r.addHeader("Cache-Control", "no-store")
        return r
    }

    private fun login(s: IHTTPSession): Response {
        val now = System.currentTimeMillis()
        if (now < lockUntil) {
            return json(Status.FORBIDDEN, JSONObject().put("error", "Nhập sai nhiều lần, thử lại sau ít giây"))
        }
        val given = param(s, "pin")
        if (MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
            fails = 0
            val r = json(Status.OK, JSONObject().put("ok", true))
            r.addHeader("Set-Cookie", "tok=$token; Path=/; HttpOnly; SameSite=Lax")
            return r
        }
        fails++
        if (fails >= 5) {
            fails = 0
            lockUntil = now + 30_000
        }
        return json(Status.UNAUTHORIZED, JSONObject().put("error", "Sai mã PIN"))
    }

    private fun ls(rel: String): Response {
        val d = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!d.isDirectory) return json(Status.NOT_FOUND, JSONObject().put("error", "Không phải thư mục"))
        val list = d.listFiles()
        val items = (list ?: emptyArray())
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
        val arr = JSONArray()
        for (f in items) {
            arr.put(
                JSONObject().put("name", f.name).put("dir", f.isDirectory)
                    .put("size", if (f.isDirectory) 0L else f.length()).put("time", f.lastModified())
            )
        }
        return json(
            Status.OK,
            JSONObject().put("path", relOf(d)).put("entries", arr).put("denied", list == null)
        )
    }

    private fun download(rel: String): Response {
        val f = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!f.isFile || !f.canRead()) return json(Status.NOT_FOUND, JSONObject().put("error", "Không đọc được file"))
        val r = NanoHTTPD.newFixedLengthResponse(
            Status.OK, "application/octet-stream", FileInputStream(f), f.length()
        )
        r.addHeader("Content-Disposition", disposition(f.name))
        return r
    }

    private fun zip(rel: String): Response {
        val d = resolve(rel) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!d.isDirectory) return json(Status.NOT_FOUND, JSONObject().put("error", "Không phải thư mục"))
        val pipeIn = PipedInputStream(1 shl 16)
        val pipeOut = PipedOutputStream(pipeIn)
        Thread {
            try {
                ZipOutputStream(BufferedOutputStream(pipeOut)).use { z ->
                    z.setLevel(1)
                    addDir(z, d, "")
                }
            } catch (e: Exception) {
                try { pipeOut.close() } catch (_: Exception) {}
            }
        }.start()
        val r = NanoHTTPD.newChunkedResponse(Status.OK, "application/zip", pipeIn)
        val name = if (d.path == rootC.path) "Bo-nho-trong" else d.name
        r.addHeader("Content-Disposition", disposition("$name.zip"))
        return r
    }

    private fun addDir(z: ZipOutputStream, dir: File, prefix: String) {
        val list = dir.listFiles() ?: return
        for (f in list) {
            if (Files.isSymbolicLink(f.toPath())) continue
            if (f.isDirectory) {
                addDir(z, f, prefix + f.name + "/")
            } else if (f.isFile) {
                val ins = try { FileInputStream(f) } catch (e: Exception) { continue }
                ins.use {
                    z.putNextEntry(ZipEntry(prefix + f.name))
                    it.copyTo(z)
                    z.closeEntry()
                }
            }
        }
    }

    /** Nhận file thô vào thư mục ?path=..., tên file ở ?name=... */
    private fun upload(s: IHTTPSession): Response {
        val len = s.headers["content-length"]?.toLongOrNull()
            ?: return json(Status.BAD_REQUEST, JSONObject().put("error", "Missing Content-Length"))
        val dir = resolve(param(s, "path")) ?: return json(Status.FORBIDDEN, JSONObject().put("error", "Không hợp lệ"))
        if (!dir.isDirectory || !dir.canWrite()) {
            return json(Status.FORBIDDEN, JSONObject().put("error", "Không có quyền ghi vào thư mục này"))
        }
        val name = Storage.safeName(param(s, "name").ifEmpty { "file" })
        val tmp = File(dir, ".upload_" + System.nanoTime())
        var ok = false
        try {
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                val ins = s.inputStream
                var rem = len
                while (rem > 0) {
                    val n = ins.read(buf, 0, minOf(buf.size.toLong(), rem).toInt())
                    if (n < 0) throw IOException("Connection closed")
                    out.write(buf, 0, n)
                    rem -= n
                }
            }
            val target = Storage.unique(dir, name)
            ok = tmp.renameTo(target)
            if (!ok) throw IOException("Cannot save file")
            onChange()
            return json(Status.OK, JSONObject().put("ok", true).put("name", target.name))
        } finally {
            if (!ok) tmp.delete()
        }
    }
}
